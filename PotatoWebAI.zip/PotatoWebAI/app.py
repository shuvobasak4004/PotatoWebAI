#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import os

app = Flask(__name__)

# Load your trained model
model = load_model('C:/Users/AIC\Downloads/LeafDiseaseDetection/LeafDiseaseDetection/thesisCnn30.h5')

# Define the upload folder and allowed extensions
UPLOAD_FOLDER = 'static/images'
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Map class indices to class labels
class_labels = {
    0: 'Potato_Early_Blight',
    1: 'healthy',
    2: 'Potato_Late_Blight'
}

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

# ... (your existing Flask code)

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return render_template('index.html', message='No file part')

    file = request.files['file']

    if file.filename == '':
        return render_template('index.html', message='No selected file')

    if file and allowed_file(file.filename):
        # Save the uploaded image to the upload folder
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        # Perform image preprocessing
        img = image.load_img(file_path, target_size=(256, 256))  # Set your target size
        img_array = image.img_to_array(img)
        img_array = img_array / 255.0  # Normalize the pixel values
        img_array = img_array.reshape((1,) + img_array.shape)

        # Use the loaded model for prediction
        result = model.predict(img_array)

        # Map the predicted class index to its label
        predicted_class_index = result.argmax(axis=-1)
        predicted_class_label = class_labels[predicted_class_index[0]]

        # Get the confidence score (probability) for the predicted class
        confidence_score = result[0][predicted_class_index[0]]

        # Display the prediction result and accuracy on the webpage
        return render_template('index.html', result=predicted_class_label, accuracy=confidence_score, image_file=file.filename)

    else:
        return render_template('index.html', message='Invalid file format')

# ... (the rest of your existing Flask code)


if __name__ == '__main__':
    app.run(debug=True)

